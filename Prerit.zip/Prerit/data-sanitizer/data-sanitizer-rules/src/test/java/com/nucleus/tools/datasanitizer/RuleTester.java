package com.nucleus.tools.datasanitizer;

import java.io.FileInputStream;

import org.apache.commons.lang.SerializationUtils;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.nucleus.tools.datasanitizer.lms.RepaymentBillingStopBillFlag;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RuleTester {
	
	@Test
	public void test1() throws Exception{
		String inputFile = "loan.ser";
		FileInputStream fileInputStream = new FileInputStream(new ClassPathResource(inputFile).getFile());
		RootObject root = (RootObject)SerializationUtils.deserialize(fileInputStream);
		Logger logger = new Logger(); 
		RuleExecutor rule = new RepaymentBillingStopBillFlag();
		boolean shouldExecute = rule.shouldExecute(root);
		boolean result = rule.execute(root, logger);
	}

}
