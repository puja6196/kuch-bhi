package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;
import org.springframework.stereotype.Component;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.AutowiredRule;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

@Component
public class DisbursalAmountRuleAutowired implements RuleExecutor, AutowiredRule{
	
	@Override
	public boolean execute(RootObject context,Logger logger) {
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
		BigDecimal loanDisbursalAmount = (BigDecimal) ctx.getValue("/loan_account/disbursal_details/DISBURSAL_AMT", BigDecimal.class);
		
		
	      List<Map<?,?>> disbursalDetailsBreakup = MVEL.eval("loan_account.?disbursal_details.?disbursal_details_breakup", context, List.class);
          if(disbursalDetailsBreakup != null){
//        	  Long sum =  (long) ((BigDecimal) disbursalDetailsBreakup.stream().filter(ddb -> "A".equals(ddb.get("DISBURSAL_STATUS"))).mapToInt(ddb ->  (BigDecimal)ddb.get("DISBURSAL_AMT"))).intValue().sum();
        	 BigDecimal sum = disbursalDetailsBreakup.stream().filter(ddb -> "A".equals(ddb.get("DISBURSAL_STATUS"))).map(ddb ->  (BigDecimal)ddb.get("DISBURSAL_AMT")).reduce(BigDecimal.ZERO, BigDecimal::add);
          

		
		
		if (loanDisbursalAmount.compareTo(sum) ==0){
			logList.add("Disbursed Amount matches with Disbusal Break Up.");
			logger.setLog(logList);
			return true;
		}else
		{
			logList.add("Disbursed Amount does not match with Disbusal Break Up. Disbursed Amount : "+loanDisbursalAmount+" ,Disbursal break up : "+sum+".");
			logger.setLog(logList);
			return false;
		}
          }
          return false;

	}
	
	@Override
	public boolean shouldExecute(RootObject context) {
		//JXPathContext ctx = JXPathContext.newContext(context);
		//String freezeFlag = (String)ctx.getValue("/loan_account/FREEZE_LOAN_FLAG", String.class);
		//return "N".equals(freezeFlag);
		return true;
	}

}
