package com.nucleus.tools.datasanitizer.lms;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanDetails implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		
		
		
		
		
		
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
