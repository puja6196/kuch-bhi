package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class DisbursalDetails implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	        {
    
		 JXPathContext ctx = JXPathContext.newContext(context);
		 List<Map<?,?>> disbursalDetails= MVEL.eval("loan_account.?disbursal_details", context, List.class);
		 int count=0;
		  boolean resultFlag = true;
		 List<String> logList = new ArrayList<String>();
		 Iterator<Map<?, ?>> it = disbursalDetails.iterator();
         while (it.hasNext()) 
                    {
               Map<String, String> mapValues = (Map<String, String>) it.next();
		Integer id = new Integer(0);   
		Integer disbursal_BreakupId = new Integer(0);    
		String paymentMode = null;              
		BigDecimal payment_Amount = new BigDecimal(0);           
		Date instrument_Date =  null;
		String ignore_For_Download = null;
		String disbursal_Payment_Status = null;
		BigDecimal receipt_Payment_Id= new BigDecimal(0); 
		BigDecimal dealingbank_Mst_Id =  new BigDecimal(0);
		
		for (Map.Entry entries : mapValues.entrySet()) 
		{
		if (("ID").equals(entries.getKey()))
             id = (Integer) entries.getValue();
       if (("DISBURSAL_BREAKUPID").equals(entries.getKey()))
    	   disbursal_BreakupId = ((Integer) entries.getValue());
       if (("PAYMENTMODE").equals(entries.getKey()))
    	   paymentMode = ((String) entries.getValue().toString());
       if (("PAYMENT_AMOUNT").equals(entries.getKey()))
    	   payment_Amount = (BigDecimal) (entries.getValue());
       if (("INSTRUMENT_DATE").equals(entries.getKey()))
    	   instrument_Date = ((Date) entries.getValue());
       if (("IGNORE_FOR_DOWNLOAD").equals(entries.getKey()))
    	   ignore_For_Download = ((String) entries.getValue().toString());
       if (("DISBURSAL_PAYMENT_SATTUS").equals(entries.getKey()))
    	   disbursal_Payment_Status = (String) (entries.getValue().toString());
       if (("RECEIPT_PAYMENT_ID").equals(entries.getKey()))
    	   receipt_Payment_Id = ((BigDecimal) entries.getValue());
       if (("DEALINGBANK_MST_ID").equals(entries.getKey()))
    	   dealingbank_Mst_Id = ((BigDecimal) entries.getValue());
       
       if(id==null||disbursal_BreakupId ==null|| paymentMode==null|| payment_Amount==null||instrument_Date==null|| ignore_For_Download==null||disbursal_Payment_Status==null|| receipt_Payment_Id==null||dealingbank_Mst_Id==null)
       {
    	   count=count+1;
           
       }     
       if(count!=0) 
       {
    		logList.add("One of the record is not null ");
    		
       }
       else
       {
    	   return true;}}}
		return false;
     
         }
	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}
	

	}


