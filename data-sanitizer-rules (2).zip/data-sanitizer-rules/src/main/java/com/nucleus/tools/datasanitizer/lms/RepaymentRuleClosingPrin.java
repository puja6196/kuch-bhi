package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RepaymentRuleClosingPrin implements RuleExecutor{

	@Override
	public boolean shouldExecute(RootObject context) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean execute(RootObject context,Logger logger) {
		
		List<Map<?,?>> repaymentDetails = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		List<String> logList = new ArrayList<String>();
		boolean resultFlag = true;
		if(repaymentDetails != null){
	
			
			
		Iterator<Map<?, ?>> it = repaymentDetails.iterator();
		while (it.hasNext()){
			Map<String,String> mapValues = (Map<String, String>) it.next();
			BigDecimal prevClosingPrin = new BigDecimal(0);
			BigDecimal closingPrin = new BigDecimal(0);
			BigDecimal currentBalancePrin = new BigDecimal(0);
			int countLoop=0;
			int instNumber = 0;
			String emiPemiFlag=null; 
			for (Map.Entry entries : mapValues.entrySet()){
				
				
				
					if(("EMI_PEMI_FLAG").equals(entries.getKey()))
						emiPemiFlag  = ((String) entries.getValue());
					if(("CLOSING_PRINCIPAL").equals(entries.getKey()))
						closingPrin  = ((BigDecimal) entries.getValue());
					if(("BALANCE_PRINCIPAL").equals(entries.getKey()))
						currentBalancePrin = ((BigDecimal)  entries.getValue());
					if(("INSTALMENT_NUMBER").equals(entries.getKey()))
					instNumber = ((BigDecimal) entries.getValue()).intValue();
					
					
					
			}
			
			
			if (countLoop >0 && "E".equals(emiPemiFlag)){
				if (prevClosingPrin.compareTo(currentBalancePrin) == 0 )
				{
					resultFlag = true;
				}else{
					resultFlag = false;
					logList.add("Opening Principal is not equal to the closing principal of previous installment for installment # "+instNumber +", Opening Principal : "+currentBalancePrin+", previous closing principal : "+prevClosingPrin+".");	
				 }
			}
			prevClosingPrin = closingPrin;
			countLoop++;
			
		} 
		if (resultFlag)
			logList.add("Opening Principal is equal to the closing principal of previous installment.");
			logger.setLog(logList);
			return resultFlag;
		}
		
		return false;
	}

}
