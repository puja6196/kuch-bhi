package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAccountMISData implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		List<Map<?,?>> repaySchdlDtl = MVEL.eval("loan_account.?loan_repayment", context, List.class);
		List<String> logList = new ArrayList<String>();
		if(repaySchdlDtl!=null){
			boolean returnFlag=true;
			Iterator<Map<?, ?>> it = repaySchdlDtl.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				BigDecimal effectiveIntRate = new BigDecimal(0);
				BigDecimal dueDate = null;
				Integer loanId=new Integer(0);
				BigDecimal loanIntComp = new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet()){
					if(("EFFECTIVE_INTEREST_RATE").equals(entries.getKey()))
						effectiveIntRate	 =((BigDecimal)  entries.getValue());
					if(("DUEDATE").equals(entries.getKey()))
						dueDate  = ((BigDecimal) entries.getValue());
					if("ID".equals(entries.getKey())){
						loanId= (Integer) entries.getValue();
					}	
				}
				if(effectiveIntRate==null){
					logList.add("");
					returnFlag=false;
				}
				if(dueDate>30-JUN-2015){
					logList.add("");
					returnFlag=false;
				}
		}
			if(returnFlag){
				logList.add("");
			}
			logger.setLog(logList);
			return returnFlag;
		}
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
