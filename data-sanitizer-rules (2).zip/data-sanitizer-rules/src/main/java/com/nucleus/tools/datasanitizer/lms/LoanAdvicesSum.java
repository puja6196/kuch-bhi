package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAdvicesSum implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		JXPathContext ctx = JXPathContext.newContext(context);
		String loanAccountDtl = (String) ctx.getValue("/loan_account/LMS_LOANACCOUNT_DTL/ID", String.class);
		String status = (String) ctx.getValue("/loan_account/LMS_LOANACCOUNT_DTL/STATUS", String.class);
		
		List<String> logList = new ArrayList<String>();
		if(ctx!=null)
		{
		
		List<Map<?,?>> receivablePayableDtl = MVEL.eval("loan_account.?LMS_RECEIVABLEPAYABLE_DTL", context, List.class);
			
		if(receivablePayableDtl!=null)
		{
			
			
			Iterator<Map<?, ?>> it = receivablePayableDtl.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				
               
				BigDecimal allocatedAmt=new BigDecimal(0);
				BigDecimal amtInProcess=new BigDecimal(0);
				BigDecimal originalAmt=new BigDecimal(0);
				for (Map.Entry entries : mapValues.entrySet())
				{
					if(("ALLOCATEDAMT").equals(entries.getKey()))
					{
						allocatedAmt=(BigDecimal) entries.getValue();
						if(allocatedAmt== null)
						{
							allocatedAmt=0.00;
						
						}
						}
						
					if(("AMTINPROCESS").equals(entries.getKey()))
					{
						amtInProcess	 = (BigDecimal) entries.getValue();
						if(amtInProcess== null)
						{
							amtInProcess=0;
						
						}
					
					
					}

					if(("ORIGINALAMT").equals(entries.getKey()))
						
					{
						originalAmt =  ((BigDecimal) entries.getValue());
						if(originalAmt==null)
						{
							
							originalAmt=0;
							
						}
						
					
					}
					if((allocatedAmt.add(amtInProcess)>)
					{
						
						
						
						
					}
					
					
					
					}
					
					}
					
				}
				if(allocatedAmt)
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}
		
		
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
