package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class NoRecordInLMS implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) 
	{
		// TODO Auto-generated method stub
		JXPathContext ctx = JXPathContext.newContext(context);
		List<String> logList = new ArrayList<String>();
		List<Map<?,?>> terminationHdrDetails = MVEL.eval("loan_account.?termination_hdr_details", context, List.class);
		
		List<Map<?,?>> terminationDtlDetails = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
         if(terminationDtlDetails != null)
         {
			
			Iterator<Map<?, ?>> it = terminationDtlDetails.iterator();
			while (it.hasNext()){
				Map<String,String> mapValues = (Map<String, String>) it.next();
				
				long TERMINATIONID = 0;
				
				for (Map.Entry entries : mapValues.entrySet()){

					if(("DUEDATE").equals(entries.getKey()))
						dueDate	 =(Date) entries.getValue();
					if(("BILLED_FLAG").equals(entries.getKey()))
						billFlag	 = (String) entries.getValue();
						if(("INSTALMENT_NUMBER").equals(entries.getKey()))
						instNumber =  ((BigDecimal) entries.getValue()).intValue();
						
						
				}
		
		
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
