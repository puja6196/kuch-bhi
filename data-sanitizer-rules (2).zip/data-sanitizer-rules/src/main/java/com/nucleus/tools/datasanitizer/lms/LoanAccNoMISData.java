package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAccNoMISData implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub

		 JXPathContext ctx = JXPathContext.newContext(context);
		 boolean resultFlag = true;
		 List<String> logList = new ArrayList<String>();
		 if(ctx!=null)
		 {
		
		 Long id = (Long) ctx.getValue("/loan_account/id", Long.class);
		 Long loanAccountNo = (Long) ctx.getValue("/loan_account/LMS_LOAN_MIS_DTL/LOAN_ACCOUNT_NO", Long.class);
		 Long tenantId = (Long) ctx.getValue("/loan_account/LMS_LOAN_MIS_DTL/TENANT_ID", Long.class);
		 Long loanMisId = (Long) ctx.getValue("/loan_account/LMS_LOANACCOUNT_DTL/LOAN_MIS_ID", Long.class);
		 String loanAccountDetail = (String) ctx.getValue("/loan_account/LMS_LOANACCOUNT_DTL/LOAN_ACCOUNT_NO", String.class);
		 Long tenantIdDetail = (Long) ctx.getValue("/loan_account/LMS_LOAN_MIS_DTL/TENANT_ID", Long.class);
		  if((loanMisId.equals(id)&&(loanAccountDetail.equals(loanAccountNo))&&(tenantId.equals(tenantIdDetail))))
		  {
			  
	
			  
			
			  
			  logList.add(" Records in Loan Account having  corresponding MIS data"+id);
			  return	resultFlag=false;
			  
		  }
		  logger.setLog(logList);
			return resultFlag;
		 }
		
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
