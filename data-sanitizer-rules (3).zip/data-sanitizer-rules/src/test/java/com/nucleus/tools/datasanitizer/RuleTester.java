package com.nucleus.tools.datasanitizer;

import java.io.FileInputStream;

import org.apache.commons.lang.SerializationUtils;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.nucleus.tools.datasanitizer.lms.DisbursalDetailsMandatoryFieldsNull;
import com.nucleus.tools.datasanitizer.lms.LmsLoanMisDtlLmsRepayableDtl;
import com.nucleus.tools.datasanitizer.lms.LoanAccNoMISData;
import com.nucleus.tools.datasanitizer.lms.LoanAdvicesReceivablePayableAmt;
import com.nucleus.tools.datasanitizer.lms.LoanAdvicesSum;
import com.nucleus.tools.datasanitizer.lms.LoanDetailsActiveLoan;
import com.nucleus.tools.datasanitizer.lms.LoanRepaymentProcssStatusNull;
import com.nucleus.tools.datasanitizer.lms.LoanTermManColNullLmsTermDtl;
import com.nucleus.tools.datasanitizer.lms.LoanTerminationClosureDateMismatch;
import com.nucleus.tools.datasanitizer.lms.LoanTerminationPayableAdjustedNull;
import com.nucleus.tools.datasanitizer.lms.PrabhashDisbursalDetails;
import com.nucleus.tools.datasanitizer.lms.RepaymentBillingStopBillFlag;
import com.nucleus.tools.datasanitizer.lms.RepaymentRuleInstAmount;
import com.nucleus.tools.datasanitizer.lms.RepaymentScheduleNullVapId;
import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class RuleTester {
	
	@Test
	public static void main(String [] args) throws Exception{
		String inputFile = "5000004.ser";
		FileInputStream fileInputStream = new FileInputStream(new ClassPathResource(inputFile).getFile());
		RootObject root = (RootObject)SerializationUtils.deserialize(fileInputStream);
		Logger logger = new Logger(); 
		RuleExecutor rule = new PrabhashDisbursalDetails();
		boolean shouldExecute = rule.shouldExecute(root);
		boolean result = rule.execute(root, logger);
		System.out.println(result);
		//System.out.println(root);
	}

}
