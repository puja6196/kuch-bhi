package com.nucleus.tools.datasanitizer.lms;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class LoanAdvicesReceivablePayableAmt implements RuleExecutor
{

	@Override
	public boolean execute(RootObject context, Logger logger)
	{

		   JXPathContext ctx = JXPathContext.newContext(context);
		   Boolean resultFlag=true;
		   List<String> logList = new ArrayList<String>();
		    if(ctx!=null)
		       {
			       String loanAccountDtlId = (String) ctx.getValue("/loan_account/ID", String.class);
			       char status = (char) ctx.getValue("/loan_account/STATUS", char.class);
		    	   List<Map<?,?>> receivablePayableDtl = MVEL.eval("loan_account.?advice_details", context, List.class);
		
		            if(receivablePayableDtl!=null)
		              {
			
			
			            Iterator<Map<?, ?>> it = receivablePayableDtl.iterator();
			            while (it.hasNext())
			            {
				
				        Map<String,String> mapValues = (Map<String, String>) it.next();
				
				        String loanId=null;
				        BigDecimal allocatedAmt = new BigDecimal(0);
				        BigDecimal amtInProcess=new BigDecimal(0);
				        BigDecimal receivablePayableAmt=new BigDecimal(0);
				          for (Map.Entry entries : mapValues.entrySet())
				             {
					            if(("ALLOCATEDAMT").equals(entries.getKey()))
					                {
						              allocatedAmt=(BigDecimal) entries.getValue();
						
						              if(allocatedAmt== null)
						                  {
							                   allocatedAmt=BigDecimal.valueOf(0);
						
						                  }
					                 }
						
					             if(("AMTINPROCESS").equals(entries.getKey()))
					                 {
						                amtInProcess	 = (BigDecimal) entries.getValue();
						                if(amtInProcess== null)
						                   {
							                   amtInProcess=BigDecimal.valueOf(0);
						  
						                    }
					
					
					                  }

					             if(("ORIGINALAMT").equals(entries.getKey()))
						
					                   {
						                   receivablePayableAmt =  ((BigDecimal) entries.getValue());
						
						                   if(receivablePayableAmt==null)
						                   {
							
							                    receivablePayableAmt=BigDecimal.valueOf(0);
						
						                    }
						
					
					                     }
				             }
					 if(((allocatedAmt.add(amtInProcess)).compareTo(receivablePayableAmt)==1)&&(loanAccountDtlId==loanId)&&(status=='A'))
					     {
						
					          logList.add("sum of allocated amt & amt in process is  greater than original amt");
					          resultFlag= false;	
						
					      }
			            }
					 if(resultFlag)
					 {
                        logList.add("Sum of allocated amount is not greater than original amount.");				 
						 
					 }
					
				      
				
				
					}
		            else
		            {
		            	
		            	logList.add("No record found in Receivable Payable Detail.");
		            	resultFlag=false;
		            	
		            }
					
	}
		    else
		    {
		    	logList.add("No record found.");
		    	resultFlag=false;
		    	
		    }
		
	
		
		    logger.setLog(logList);
			return resultFlag;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
