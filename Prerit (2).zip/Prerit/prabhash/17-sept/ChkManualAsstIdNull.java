package com.nucleus.tools.datasanitizer.lms;
////////////checked////////////////
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkManualAsstIdNull implements RuleExecutor {
	//checked
	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		 List<String> logList = new ArrayList<String>();
		 JXPathContext ctx = JXPathContext.newContext(context);
		 boolean returnFlag=true;
		 char autoManualClassifyFlag= (char) ctx.getValue("/loan_account/AUTO_MANUAL_CLASSIFY_FLAG", Character.class);
		 int assetClassMstId= (int) ctx.getValue("/loan_account/ASSET_CLASS_MST_ID", Integer.class);
		 String lastManualAssetMstId= (String) ctx.getValue("/loan_account/LAST_MANUAL_ASSET_CLASS_MST_ID", String.class);
		 int id=(int) ctx.getValue("/loan_account/ID", Integer.class);
		 if(autoManualClassifyFlag=='M' && assetClassMstId!=1 && lastManualAssetMstId.isEmpty()){
			 logList.add("Auto manual classify flag is 'M' and asset class mst id is not equal to 1 and last monthly asset mst id is empty for load id: "+id);
			 returnFlag=false;
		 }
		 if(returnFlag){
			 logList.add("Manual asset class id is not empty");
		 }
		logger.setLog(logList);
		return returnFlag;
	}
	
	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
