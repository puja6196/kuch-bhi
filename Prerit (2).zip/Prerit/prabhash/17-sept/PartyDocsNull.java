package com.nucleus.tools.datasanitizer.lms;
/////////// table not available
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.jxpath.JXPathContext;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class PartyDocsNull implements RuleExecutor{
	
	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		boolean returnFlag=true;
		if(ctx!=null)
		{
			String party= (String) ctx.getValue("/loan_account/PARTY", String.class);
			String partyDocs= (String) ctx.getValue("/loan_account/PARTY_DOCUMENTS", String.class);
			int loanId=(int) ctx.getValue("/loan_account/ID", Integer.class);
			if(party.isEmpty()){ //){
				logList.add("Party is empty for Load Id: "+loanId);
				returnFlag=false;
			}
			if(partyDocs.isEmpty()){
				logList.add("Party Document is empty for Load Id: "+loanId);
				returnFlag=false;
			}
			if(returnFlag){
				logList.add("Neighter party nor party documents found empty for Loan Id"+loanId);
			}
			logger.setLog(logList);
			return returnFlag;
		}
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}
	
}
