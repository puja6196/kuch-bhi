package com.nucleus.tools.datasanitizer.lms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.jxpath.JXPathContext;
import org.mvel2.MVEL;
import org.springframework.boot.logging.LogFile;

import com.nucleus.tools.datasanitizer.model.RootObject;
import com.nucleus.tools.datasanitizer.rules.Logger;
import com.nucleus.tools.datasanitizer.rules.RuleExecutor;

public class ChkMandNullTermintnDtl implements RuleExecutor{
	//ask from sir
	@Override
	public boolean execute(RootObject context, Logger logger) {
		// TODO Auto-generated method stub
		List<String> logList = new ArrayList<String>();
		JXPathContext ctx = JXPathContext.newContext(context);
		int id=(int) ctx.getValue("/loan_account/ID", Integer.class);
		String status= (String) ctx.getValue("loan_account/STATUS",String.class);
		List<Map<?,?>> terminationDtl = MVEL.eval("loan_account.?termination_dtl_details", context, List.class);
		if(terminationDtl!=null){
			boolean returnFlag=true;
			Iterator<Map<?,?>> itr= terminationDtl.iterator();
			while(itr.hasNext()){
				Map<String,String> mValues= (Map<String, String>) itr.next();
				Integer loanId= new Integer(0);
				for(Map.Entry entry:mValues.entrySet()){
					if("LOANID".equals(entry.getKey())){
						loanId=(Integer) entry.getValue();
					}
				}
				if("A".equals(status) && id==0){
					if(loanId==null){
						logList.add("Loan id empty for loan id");
						
					}
				}
			}

		}
			
		return false;
	}

	@Override
	public boolean shouldExecute(RootObject arg0) {
		// TODO Auto-generated method stub
		return true;
	}

}
